//
// Created by qicosmos on 2/13/19.
//

#ifndef CINATRA_CINATRA_HPP
#define CINATRA_CINATRA_HPP

#include "cinatra/http_server.hpp"

#endif //CINATRA_CINATRA_HPP
