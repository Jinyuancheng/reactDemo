#pragma once
#include <vector>
#include <string_view>
namespace cinatra::memento {
	inline static std::vector<std::string_view> pathinfo_mem;
}